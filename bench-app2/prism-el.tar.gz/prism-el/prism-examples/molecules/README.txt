This case study models several simple molecular reactions:

 * Na + Cl <-> Na+ + Cl-
 * K + Na + 2Cl <-> K+ + Na- + 2Cl-
 * Mg + 2Cl <-> Mg+2 + 2Cl-
 
These are taken from Ehud Shapiro's lecture notes on Biomolecular Processes as Concurrent Computation [Sha].

For more information, see: http://www.prismmodelchecker.org/casestudies/molecules.php

=====================================================================================

[Sha]
"Biomolecular Processes as Concurrent Computation" course material
http://www.wisdom.weizmann.ac.il/~biopsi/bpcc2001/
