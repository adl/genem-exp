This case study is based on the Kanban flexible manufacturing system of [CT96].

For more information, see: http://www.prismmodelchecker.org/casestudies/kanban.php

=====================================================================================

[CT96]
G. Ciardo and M. Tilgner
On the use of Kronecker Operators for the Solution of Generalized Stochastic Petri Nets
ICASE Report No. 96-35, 1996
